#include <iostream>
#include <fstream>
#include <vector>
#include <stdexcept>

class Matrix {
public:
    int N;
    std::vector<std::vector<int>> matrix;

    // Constructor
    Matrix(int size) : N(size), matrix(size, std::vector<int>(size, 0)) {}

    // Load matrix from file
    void loadMatrixFromFile(const std::string& filename) {
        std::ifstream file(filename);
        if (!file) throw std::runtime_error("Unable to open file");

        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                file >> matrix[i][j];
            }
        }
        file.close();
    }

    
    void displayMatrix() const {
        for (const auto& row : matrix) {
            for (int val : row) {
                std::cout << val << " ";
            }
            std::cout << std::endl;
        }
    }

    
    Matrix operator+(const Matrix& other) const {
        if (N != other.N) throw std::invalid_argument("Matrix sizes must be the same for addition");
        
        Matrix result(N);
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                result.matrix[i][j] = matrix[i][j] + other.matrix[i][j];
            }
        }
        return result;
    }

    
    Matrix operator*(const Matrix& other) const {
        if (N != other.N) throw std::invalid_argument("Matrix sizes must match for multiplication");

        Matrix result(N);
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                result.matrix[i][j] = 0;
                for (int k = 0; k < N; k++) {
                    result.matrix[i][j] += matrix[i][k] * other.matrix[k][j];
                }
            }
        }
        return result;
    }

    
    int sumDiagonals() const {
        int mainDiagonal = 0, secondaryDiagonal = 0;
        for (int i = 0; i < N; i++) {
            mainDiagonal += matrix[i][i];
            secondaryDiagonal += matrix[i][N - i - 1];
        }
        return mainDiagonal + secondaryDiagonal;
    }

    
    void swapRows(int row1, int row2) {
        if (row1 >= 0 && row1 < N && row2 >= 0 && row2 < N) {
            std::swap(matrix[row1], matrix[row2]);
        } else {
            throw std::out_of_range("Row indices are out of range");
        }
    }
};


int main() {
    int matrixSize = 4;  
    Matrix matA(matrixSize);
    Matrix matB(matrixSize);

    try {
        
        matA.loadMatrixFromFile("matrix-data.txt");
        matB.loadMatrixFromFile("matrix-data.txt");

        
        std::cout << "Matrix A:" << std::endl;
        matA.displayMatrix();

        std::cout << "Matrix B:" << std::endl;
        matB.displayMatrix();

        
        Matrix sumMatrix = matA + matB;
        std::cout << "Sum of A and B:" << std::endl;
        sumMatrix.displayMatrix();

        
        Matrix productMatrix = matA * matB;
        std::cout << "Product of A and B:" << std::endl;
        productMatrix.displayMatrix();

        
        std::cout << "Sum of main and secondary diagonals in A: " << matA.sumDiagonals() << std::endl;

        
        matA.swapRows(0, 1);
        std::cout << "Matrix A after swapping rows 0 and 1:" << std::endl;
        matA.displayMatrix();

    } catch (const std::exception& e) {
        std::cerr << e.what() << std::endl;
    }

    return 0;
}
